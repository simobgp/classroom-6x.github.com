document.addEventListener("DOMContentLoaded", ()=> {
  if (window.RufflePlayer) {
    const ruffle = window.RufflePlayer.newest();
    const player = ruffle.createPlayer();
    document.getElementById("player").appendChild(player);
    // load from remote location
    player.load("https://simobgp.github.io/gamulo.com-game1/billy_bob.swf");
  } else {
    document.body.insertAdjacentHTML("beforeend","<p style='color:red;'>Ruffle failed to load.</p>");
  }
});
